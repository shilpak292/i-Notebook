# inotebook

A MERN full-stack project : stores digital notes of differents users and manages their accounts and notes
